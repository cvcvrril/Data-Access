package dao.mongo;

public class DaoMongoMenuItem {
}
