package dao;

import model.Credential;

public interface DaoLogin {
    boolean doLogin(Credential credential);

}
