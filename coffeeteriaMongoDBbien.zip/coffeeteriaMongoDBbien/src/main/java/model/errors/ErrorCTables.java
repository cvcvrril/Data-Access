package model.errors;

public class ErrorCTables extends ErrorC{
    public ErrorCTables(String message, int numError) {
        super(message, numError);
    }
}
