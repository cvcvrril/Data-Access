package model.errors;

public class ErrorCCustomer extends ErrorC{
    public ErrorCCustomer(String message, int numError) {
        super(message, numError);
    }
}
