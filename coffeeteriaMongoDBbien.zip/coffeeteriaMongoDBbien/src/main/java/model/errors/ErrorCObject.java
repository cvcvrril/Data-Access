package model.errors;

public class ErrorCObject extends ErrorC{
    public ErrorCObject(String message, int numError) {
        super(message, numError);
    }
}
