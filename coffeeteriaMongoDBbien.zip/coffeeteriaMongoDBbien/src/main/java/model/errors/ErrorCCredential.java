package model.errors;

public class ErrorCCredential extends ErrorC{
    public ErrorCCredential(String message, int numError) {
        super(message, numError);
    }
}
