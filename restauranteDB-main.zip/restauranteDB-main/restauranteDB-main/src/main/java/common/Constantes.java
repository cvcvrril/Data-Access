package common;

public class Constantes {
    public static final String Welcome= "Welcome ";
    public static final String UserADD = "Added User: ";
    public static final String UserDEL = "Are you sure you want to delete the client: ";
    public static final String OrderDEL = "Are you sure you want to delete the order?: ";
    public static final String UserUPD = "Updated User: ";
    public static final String OrderUPD = "Updated Order: ";
    public static final String LOG4J="There was an error";
}