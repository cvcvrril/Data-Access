package common;

public class SqlQueries {
    public static final String SELECT_ALL_FROM_WEAPONS = "select * from weapons";
}
