package ui.exercises;

public class MainExercise2 {
}
