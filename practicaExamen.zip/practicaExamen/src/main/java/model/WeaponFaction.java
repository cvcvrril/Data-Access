package model;

import java.time.LocalDate;

public class WeaponFaction {


}
